

int initall(void);
int enditall(void);
